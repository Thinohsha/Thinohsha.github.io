package chess;

public class Launcher {

}
